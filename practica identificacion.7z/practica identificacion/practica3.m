input = transpose(double(out.ref));
output = transpose(double(out.angulo));

%pzmap(tf2)

t = linspace(0, length(output)*0.02, length(output));

%figure()
%hold on;
%step(45*tf1);
%stem(t, output);

y = output(3:end);

col1= output(2:end-1);
col2= output(1:end-2);
col3= input(2:end-1);
col4=input(1:end-2);
M=transpose([col1; col2;col3;col4]);

a = transpose(M) * M;

alfa =  (a)^-1  * transpose(M) * transpose(y);

tf_estimada = tf([0,alfa(3),alfa(4)],[1,-alfa(1),-alfa(2)],0.02)

figure();
hold on;
step(-45*tf_estimada);
plot(t,output,"red");
legend('estimada','real')
hold off;


figure();
hold on;
step(-45*d2c(tf_estimada,'tustin'));
plot(t,output,"red");
legend('estimada','real')
hold off;